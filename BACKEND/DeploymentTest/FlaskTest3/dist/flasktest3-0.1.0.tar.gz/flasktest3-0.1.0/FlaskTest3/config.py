DBINFO = {
  'user'     : 'root',
  'password' : 'c2VtaWNvbG9u',
  'host'     : '127.0.0.1',
  'port'     :  3306,
  'database' : 'semicolondb',
}

DBURI = f"mysql+pymysql://{DBINFO['user']}:{DBINFO['password']}@{DBINFO['host']}:{DBINFO['port']}/{DBINFO['database']}"



