# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flasktest3', 'flasktest3.apis', 'flasktest3.model']

package_data = \
{'': ['*']}

install_requires = \
['Flask==2.1.2',
 'PyMySQL==1.0.2',
 'Werkzeug==2.1.2',
 'flask-restx==0.5.1',
 'flask-sqlalchemy==2.5.1',
 'gunicorn>=20.1.0,<21.0.0']

setup_kwargs = {
    'name': 'flasktest3',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'greennarae',
    'author_email': 'smk5647@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
